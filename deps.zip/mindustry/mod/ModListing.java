package mindustry.mod;

/** Mod listing as a data class. */
public class ModListing{
    public String repo, name, internalName, author, lastUpdated, description, minGameVersion, version;
    public boolean hasScripts, hasJava, iosCompatible, legacyCompatible, hasIcon;
    public String[] contentTypes = {};
    public int stars;

    @Override
    public String toString(){
        return "ModListing{" +
        "repo='" + repo + '\'' +
        ", name='" + name + '\'' +
        ", internalName='" + internalName + '\'' +
        ", author='" + author + '\'' +
        ", lastUpdated='" + lastUpdated + '\'' +
        ", description='" + description + '\'' +
        ", minGameVersion='" + minGameVersion + '\'' +
        ", hasScripts=" + hasScripts +
        ", hasJava=" + hasJava +
        ", stars=" + stars +
        '}';
    }
}
